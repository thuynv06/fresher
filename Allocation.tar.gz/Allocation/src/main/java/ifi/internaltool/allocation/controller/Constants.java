package ifi.internaltool.allocation.controller;

public class Constants {
	private String constants;
	
	public Constants() {
		
	}
	
	public String ERROR_CODE() {
		return "ERROR_CODE";
	}
	public String STATUS_KO() {
		return "STATUS_KO";
	}
	public String STATUS_OK() {
		return "STATUS_OK";
	}
	public String SUCCESS_CODE() {
		return "SUCCESS_CODE";
	}
}
